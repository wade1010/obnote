<?php
require_once('./hprose/src/Hprose.php');
$client = new HproseHttpClient('http://127.0.0.1:3030');
echo $client->hello('程信辉');