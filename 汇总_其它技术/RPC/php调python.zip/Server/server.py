#!/usr/local/bin/python2.6
# encoding: utf-8

from hprose.httpserver import HproseHttpServer

def hello(name):
    return  'Hello' + ' ' + name;

server = HproseHttpServer(port=3030)
server.addFunction(hello)
server.start()